// Array de productos actualizados
const productos = [
    { id: 1, nombre: 'Camiseta Roja', talla: 'M', precio: 25, color: 'rojo', stock: 10, img: 'camiseta_roja.jpg' },
    { id: 2, nombre: 'Pantalón Azul', talla: 'L', precio: 40, color: 'azul', stock: 5, img: 'pantalon_azul.jpg' },
    { id: 3, nombre: 'Camiseta Negra', talla: 'S', precio: 30, color: 'negro', stock: 8, img: 'camiseta_negra.png' },
    { id: 4, nombre: 'Sudadera Azul', talla: 'XL', precio: 50, color: 'azul', stock: 4, img: 'sudadera_azul.jpg' },
    { id: 5, nombre: 'Short Deportivo', talla: 'M', precio: 35, color: 'negro', stock: 7, img: 'short_deportivo.jpeg' },
    { id: 6, nombre: 'Gorra Blanca', talla: 'M', precio: 15, color: 'blanco', stock: 12, img: 'gorra_blanca.jpeg' },
    { id: 7, nombre: 'Chaqueta de Cuero', talla: 'L', precio: 120, color: 'negro', stock: 2, img: 'chaqueta_cuero.jpg' },
    { id: 8, nombre: 'Bufanda Roja', talla: 'M', precio: 20, color: 'rojo', stock: 6, img: 'bufanda_roja.jpg' },
    { id: 9, nombre: 'Pantalón Blanco', talla: 'M', precio: 45, color: 'blanco', stock: 0, img: 'pantalon_blanco.jpeg' },
    { id: 10, nombre: 'Vestido Azul', talla: 'S', precio: 60, color: 'azul', stock: 5, img: 'vestido_azul.jpg' },
];

// Array del carrito de compras
let carrito = [];

// Función para crear el HTML del producto
function crearProductoHTML(producto) {
    return `
        <div class="producto">
            <img src="${producto.img}" alt="${producto.nombre}">
            <h3>${producto.nombre}</h3>
            <p>Talla: ${producto.talla}</p>
            <p>Color: ${producto.color}</p>
            <p>Precio: $${producto.precio}</p>
            <p>Stock: ${producto.stock}</p>
            <button onclick="agregarAlCarrito(${producto.id})" ${producto.stock === 0 ? 'disabled' : ''}>
                ${producto.stock === 0 ? 'Pre-ordenar' : 'Agregar al Carrito'}
            </button>
            <p class="stock-alert" id="alertaStock${producto.id}"></p>
        </div>
    `;
}

// Función para cargar el catálogo y aplicar filtros
function cargarCatalogo() {
    const catalogo = document.querySelector('.productos');
    catalogo.innerHTML = '';

    const talla = document.getElementById('talla').value;
    const color = document.getElementById('color').value;

    const productosFiltrados = productos.filter(p => 
        (talla === 'todos' || p.talla === talla) &&
        (color === 'todos' || p.color === color)
    );

    productosFiltrados.forEach(producto => {
        catalogo.innerHTML += crearProductoHTML(producto);
    });

    verificarStock();
}

// Función para verificar el stock y mostrar notificaciones
function verificarStock() {
    productos.forEach(producto => {
        const alertaStock = document.getElementById(`alertaStock${producto.id}`);
        alertaStock.innerText = '';

        if (producto.stock <= 5 && producto.stock > 0) {
            alertaStock.innerText = '¡Stock bajo!';
            alertaStock.classList.add('stock-bajo');
        } else if (producto.stock === 0) {
            alertaStock.innerHTML = 'Producto agotado. Puedes pre-ordenarlo.';
            alertaStock.classList.add('agotado');
        }
    });
}

// Función para agregar al carrito
function agregarAlCarrito(idProducto) {
    const producto = productos.find(p => p.id === idProducto);
    if (producto && producto.stock > 0) {
        const productoEnCarrito = carrito.find(p => p.id === producto.id);
        productoEnCarrito ? productoEnCarrito.cantidad++ : carrito.push({ ...producto, cantidad: 1 });
        producto.stock--;
        actualizarCarrito();
        cargarCatalogo(); // Actualizar catálogo con el stock modificado
    } else {
        alert('Producto agotado');
    }
}

// Función para eliminar un producto del carrito
function eliminarDelCarrito(idProducto) {
    const productoEnCarrito = carrito.find(p => p.id === idProducto);
    if (productoEnCarrito) {
        const productoOriginal = productos.find(p => p.id === idProducto);
        productoOriginal.stock += productoEnCarrito.cantidad;
        carrito = carrito.filter(p => p.id !== idProducto);
        actualizarCarrito();
        cargarCatalogo(); // Actualizar catálogo con el stock modificado
    }
}

// Función para actualizar el carrito
function actualizarCarrito() {
    const resumenCarrito = document.getElementById('resumenCarrito');
    resumenCarrito.innerHTML = '';

    let total = 0;
    carrito.forEach(producto => {
        const subtotal = producto.precio * producto.cantidad;
        resumenCarrito.innerHTML += `
            <p>${producto.nombre} (x${producto.cantidad}) - $${subtotal}
            <button onclick="eliminarDelCarrito(${producto.id})">Eliminar</button></p>
        `;
        total += subtotal;
    });
    resumenCarrito.innerHTML += `<p><strong>Total: $${total}</strong></p>`;
}

// Función para procesar el pago
function procesarPago(event) {
    event.preventDefault();

    const nombre = document.getElementById('nombre').value;
    const numeroTarjeta = document.getElementById('numeroTarjeta').value;
    const fechaExpiracion = document.getElementById('fechaExpiracion').value;
    const cvv = document.getElementById('cvv').value;
    const opcionPago = document.getElementById('opcionPago').value;
    const guardarPago = document.getElementById('guardarPago').checked;

    if (!nombre || !numeroTarjeta || !fechaExpiracion || !cvv || !opcionPago) {
        alert('Por favor, complete todos los campos.');
        return;
    }

    alert('Pago procesado con éxito. Generando factura...');
    generarFactura(nombre, numeroTarjeta, fechaExpiracion, cvv, opcionPago, guardarPago);

    carrito = [];
    actualizarCarrito();
    cargarCatalogo();
    cerrarModal();
}

// Función para generar factura usando jsPDF
function generarFactura(nombre, numeroTarjeta, fechaExpiracion, cvv, opcionPago, guardarPago) {
    const { jsPDF } = window.jspdf;
    const doc = new jsPDF();

    doc.setFontSize(20);
    doc.text('Factura de Compra', 105, 20, null, null, 'center');
    doc.setFontSize(12);
    doc.text(`Nombre: ${nombre}`, 20, 40);
    doc.text(`Método de Pago: ${opcionPago}`, 20, 50);
    doc.text(`Fecha de Expiración: ${fechaExpiracion}`, 20, 60);
    doc.text(`Tarjeta: **** **** **** ${numeroTarjeta.slice(-4)}`, 20, 70);
    if (guardarPago) {
        doc.text('Datos de tarjeta guardados para futuras compras.', 20, 80);
    }

    doc.text('Productos:', 20, 100);
    let y = 110;
    let total = 0;
    carrito.forEach(producto => {
        const subtotal = producto.precio * producto.cantidad;
        doc.text(`${producto.nombre} (x${producto.cantidad}) - $${subtotal}`, 20, y);
        total += subtotal;
        y += 10;
    });

    doc.setFontSize(14);
    doc.text(`Total: $${total}`, 20, y + 10);
    doc.save('factura.pdf');
}

// Funciones para manejar el modal de pago
function abrirModal() {
    const modal = document.getElementById('modalPago');
    modal.style.display = 'block';
}

function cerrarModal() {
    const modal = document.getElementById('modalPago');
    modal.style.display = 'none';
}

// Event listener para abrir el modal al hacer clic en "Comprar"
document.getElementById('comprarBtn').addEventListener('click', () => {
    if (carrito.length === 0) {
        alert('El carrito está vacío.');
        return;
    }
    abrirModal();
});

// Event listener para cerrar el modal al hacer clic en la 'x'
document.querySelector('.cerrar').addEventListener('click', cerrarModal);

// Event listener para cerrar el modal al hacer clic fuera del contenido
window.addEventListener('click', (event) => {
    const modal = document.getElementById('modalPago');
    if (event.target === modal) {
        cerrarModal();
    }
});

// Inicializar página
document.addEventListener('DOMContentLoaded', () => {
    cargarCatalogo();

    document.getElementById('categoria').addEventListener('change', cargarCatalogo);
    document.getElementById('talla').addEventListener('change', cargarCatalogo);
    document.getElementById('color').addEventListener('change', cargarCatalogo);
});
