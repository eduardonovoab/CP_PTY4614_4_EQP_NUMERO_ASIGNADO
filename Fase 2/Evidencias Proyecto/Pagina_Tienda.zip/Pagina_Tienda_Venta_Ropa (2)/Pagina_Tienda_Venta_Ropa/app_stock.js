let productos = [
    { id: 1, nombre: 'Camiseta Roja', talla: 'M', precio: 25, color: 'rojo', stock: 10, img: 'camiseta_roja.jpg' },
    { id: 2, nombre: 'Pantalón Azul', talla: 'L', precio: 40, color: 'azul', stock: 5, img: 'pantalon_azul.jpg' },
    { id: 3, nombre: 'Camiseta Negra', talla: 'S', precio: 30, color: 'negro', stock: 8, img: 'camiseta_negra.png' },
    { id: 4, nombre: 'Sudadera Azul', talla: 'XL', precio: 50, color: 'azul', stock: 4, img: 'sudadera_azul.jpg' },
    { id: 5, nombre: 'Short Deportivo', talla: 'M', precio: 35, color: 'negro', stock: 7, img: 'short_deportivo.jpeg' },
    { id: 6, nombre: 'Gorra Blanca', talla: 'M', precio: 15, color: 'blanco', stock: 12, img: 'gorra_blanca.jpeg' },
    { id: 7, nombre: 'Chaqueta de Cuero', talla: 'L', precio: 120, color: 'negro', stock: 2, img: 'chaqueta_cuero.jpg' },
    { id: 8, nombre: 'Bufanda Roja', talla: 'M', precio: 20, color: 'rojo', stock: 6, img: 'bufanda_roja.jpg' },
    { id: 9, nombre: 'Pantalón Blanco', talla: 'M', precio: 45, color: 'blanco', stock: 0, img: 'pantalon_blanco.jpeg' },
    { id: 10, nombre: 'Vestido Azul', talla: 'S', precio: 60, color: 'azul', stock: 5, img: 'vestido_azul.jpg' },
];

// Cargar catálogo de productos
function cargarCatalogo() {
    let catalogo = document.querySelector('.productos');
    catalogo.innerHTML = '';

    productos.forEach(producto => {
        let productoHTML = `
            <div class="producto">
                <img src="${producto.img}" alt="${producto.nombre}">
                <h3>${producto.nombre}</h3>
                <p>Talla: ${producto.talla}</p>
                <p>Color: ${producto.color}</p>
                <p>Precio: $${producto.precio}</p>
                <p>Stock: <span id="stock${producto.id}">${producto.stock}</span></p>
                <button id="btn${producto.id}" onclick="preOrdenar(${producto.id})" ${producto.stock === 0 ? '' : 'disabled'}>
                    ${producto.stock === 0 ? 'Pre-ordenar' : 'Disponible'}
                </button>
                <p class="stock-alert" id="alertaStock${producto.id}"></p>
            </div>
        `;
        catalogo.innerHTML += productoHTML;
    });

    verificarStock();
}

// Verificar el stock y mostrar notificaciones
function verificarStock() {
    productos.forEach(producto => {
        let alertaStock = document.getElementById(`alertaStock${producto.id}`);

        if (producto.stock <= 5 && producto.stock > 0) {
            alertaStock.innerText = '¡Stock bajo!';
        } else if (producto.stock === 0) {
            alertaStock.innerHTML = 'Producto agotado. Puedes pre-ordenarlo.';
        }
    });
}

// Simular pre-ordenar un producto agotado
function preOrdenar(idProducto) {
    let producto = productos.find(p => p.id === idProducto);
    if (producto && producto.stock === 0) {
        // Aquí puedes agregar lógica para actualizar la base de datos
        alert(`Has pre-ordenado ${producto.nombre}. Te notificaremos cuando vuelva a estar disponible.`);
    }
}

// Inicializar la página
document.addEventListener('DOMContentLoaded', cargarCatalogo);
