-- Creación de tablas para la base de datos de la tienda online

-- Crear tabla de productos
CREATE TABLE productos (
    producto_id NUMBER(11) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    categoria VARCHAR2(50),
    talla VARCHAR2(10),
    color VARCHAR2(20),
    precio NUMBER(10,2) NOT NULL,
    stock NUMBER(11) DEFAULT 0,
    img_url VARCHAR2(255),
    CONSTRAINT productos_pk PRIMARY KEY (producto_id)
);

-- Crear tabla de usuarios
CREATE TABLE usuarios (
    usuario_id NUMBER(11) NOT NULL,
    nombre VARCHAR2(100) NOT NULL,
    contrasena VARCHAR2(255) NOT NULL,
    fecha_registro DATE NOT NULL,
    tipo_usuario VARCHAR2(20) CHECK (tipo_usuario IN ('cliente', 'administrador')),
    CONSTRAINT usuarios_pk PRIMARY KEY (usuario_id)
);

-- Crear tabla de ventas
CREATE TABLE ventas (
    venta_id NUMBER(11) NOT NULL,
    usuario_id NUMBER(11) NOT NULL,
    fecha_venta DATE NOT NULL,
    total NUMBER(10,2) NOT NULL,
    CONSTRAINT ventas_pk PRIMARY KEY (venta_id),
    CONSTRAINT ventas_usuario_fk FOREIGN KEY (usuario_id) REFERENCES usuarios (usuario_id)
);

-- Crear tabla de detalle de ventas
CREATE TABLE detalle_ventas (
    detalle_id NUMBER(11) NOT NULL,
    venta_id NUMBER(11) NOT NULL,
    producto_id NUMBER(11) NOT NULL,
    cantidad NUMBER(11) NOT NULL,
    precio NUMBER(10,2) NOT NULL,
    CONSTRAINT detalle_ventas_pk PRIMARY KEY (detalle_id),
    CONSTRAINT detalle_ventas_venta_fk FOREIGN KEY (venta_id) REFERENCES ventas (venta_id),
    CONSTRAINT detalle_ventas_producto_fk FOREIGN KEY (producto_id) REFERENCES productos (producto_id)
);

-- Crear tabla de pagos
CREATE TABLE pagos (
    pago_id NUMBER(11) NOT NULL,
    venta_id NUMBER(11) NOT NULL,
    metodo_pago VARCHAR2(20) CHECK (metodo_pago IN ('tarjeta', 'transbank')) NOT NULL,
    monto NUMBER(10,2) NOT NULL,
    fecha_pago DATE NOT NULL,
    CONSTRAINT pagos_pk PRIMARY KEY (pago_id),
    CONSTRAINT pagos_venta_fk FOREIGN KEY (venta_id) REFERENCES ventas (venta_id)
);

-- Crear tabla de carrito
CREATE TABLE carrito (
    carrito_id NUMBER(11) NOT NULL,
    producto_id NUMBER(11) NOT NULL,
    nombre VARCHAR2(255),
    precio NUMBER(10,2),
    cantidad NUMBER(11) DEFAULT 1,
    CONSTRAINT carrito_pk PRIMARY KEY (carrito_id),
    CONSTRAINT carrito_producto_fk FOREIGN KEY (producto_id) REFERENCES productos (producto_id)
);

-- Secuencias para las tablas
CREATE SEQUENCE seq_productos START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_usuarios START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_ventas START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_detalle_ventas START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_pagos START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;
CREATE SEQUENCE seq_carrito START WITH 1 INCREMENT BY 1 NOCACHE NOCYCLE;

-- Triggers para auto-incrementar los ID's
CREATE OR REPLACE TRIGGER trg_productos_bi
BEFORE INSERT ON productos
FOR EACH ROW
BEGIN
  SELECT seq_productos.NEXTVAL INTO :NEW.producto_id FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_usuarios_bi
BEFORE INSERT ON usuarios
FOR EACH ROW
BEGIN
  SELECT seq_usuarios.NEXTVAL INTO :NEW.usuario_id FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_ventas_bi
BEFORE INSERT ON ventas
FOR EACH ROW
BEGIN
  SELECT seq_ventas.NEXTVAL INTO :NEW.venta_id FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_detalle_ventas_bi
BEFORE INSERT ON detalle_ventas
FOR EACH ROW
BEGIN
  SELECT seq_detalle_ventas.NEXTVAL INTO :NEW.detalle_id FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_pagos_bi
BEFORE INSERT ON pagos
FOR EACH ROW
BEGIN
  SELECT seq_pagos.NEXTVAL INTO :NEW.pago_id FROM dual;
END;
/

CREATE OR REPLACE TRIGGER trg_carrito_bi
BEFORE INSERT ON carrito
FOR EACH ROW
BEGIN
  SELECT seq_carrito.NEXTVAL INTO :NEW.carrito_id FROM dual;
END;
/
